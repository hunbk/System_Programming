<?php
echo "Hello PHP world!!";
?>
